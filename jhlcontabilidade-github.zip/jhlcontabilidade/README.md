# JHL Contabilidade, Fiscal e Planejamento

Site institucional da JHL Contabilidade, Fiscal e Planejamento.

## GitHub Pages

1. Crie um repositório público chamado `jhlcontabilidade`.
2. Envie estes arquivos para a branch `main`.
3. Vá em **Settings > Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`.
6. Salve. O GitHub Pages publicará o site.

## Contato

WhatsApp: (15) 99259-9860  
Atendimento: Piracicaba e região
